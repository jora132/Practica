package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class RebutPassword2 extends AppCompatActivity {

public static String email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rebut_password2);
    }
    public void GoRebFirst(View v){
        Intent intent = new Intent(this, RebutPassword.class);
        startActivity(intent);
    }
    public void finish(View view)
    {
        EditText passwordEditText = (EditText) findViewById(R.id.editTextTextPersonName7);
        String password = passwordEditText.getText().toString();


        try
        {


            OkHttpClient client = new OkHttpClient();
            String url = "https://smtpservers.ru/projects/Kochnev/resetPassword?email="+email+"&password="+password;
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            Call call = client.newCall(request);
            Handler handler = new Handler(Looper.getMainLooper());
            call.enqueue(new Callback() {
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String responseBody = response.body().string();

                    if(responseBody.equals("500")){
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "Произошла ошибка поробуйте позже!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    else{

                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                run1();
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call call, IOException e) {
                    String error = e.toString();
                }
            });

    }catch (Exception e)

        {

        }
    }

        public void run1()
        {
            startActivity(new Intent(this, MainActivity.class));
        }
}