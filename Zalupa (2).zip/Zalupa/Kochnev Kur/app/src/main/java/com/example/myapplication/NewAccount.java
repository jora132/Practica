package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class NewAccount extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_account);

    }


    public void GoMainBack(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void CreateAccount(View view)
    {
        EditText emailEditText = (EditText) findViewById(R.id.Email);
        String email = emailEditText.getText().toString();

        EditText nameEditText = (EditText) findViewById(R.id.Name);
        String name = nameEditText.getText().toString();

        EditText passwordEditText = (EditText) findViewById(R.id.Pass);
        String password = passwordEditText.getText().toString();
        if(isValidEmail(email)){
            OkHttpClient client = new OkHttpClient();
            String url = "https://smtpservers.ru/projects/Kochnev/registerUsers?email="+email+"&password="+password+"&name="+name;
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String responseBody = response.body().string();
                    if(responseBody.equals("004")){
                        Handler handler = new Handler(Looper.getMainLooper());
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "Аккаунт с таким email-адрессом уже зарегистрирован!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    else{
                        Handler handler = new Handler(Looper.getMainLooper());
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "Аккаунт зарегистрирован!", Toast.LENGTH_SHORT).show();
                            }
                        });
                        //открытие новой активности
                    }
                }

                @Override
                public void onFailure(Call call, IOException e) {
                    String error = e.toString();
                }

            });
        }
        else
        {
            Toast.makeText(getApplicationContext(), "неверно введен email!", Toast.LENGTH_SHORT).show();
        }

    }
    public static boolean isValidEmail(String email) {
        // Проверяем на null
        if (email == null) {
            return false;
        }

        // Задаем паттерн регулярного выражения для email
        Pattern pattern = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

        // Сравниваем строку с паттерном
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
}