package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


import com.google.gson.Gson;

import java.io.IOException;
import java.lang.ref.Reference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    public void goNews(View viev)
    {
        startActivity(new Intent(this, News.class));
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.deleteDatabase("users.db");

    }
    public void GoFirstReb (View v){
        Intent intent = new Intent(this, RebutPassword.class);
        startActivity(intent);
    }
    public void Newacc(View v)
    {

        Intent intent = new Intent(this, NewAccount.class);
        startActivity(intent);
    }
    public void autorization(View view)
    {
        EditText emailEditText = (EditText) findViewById(R.id.edEmail);
        String email = emailEditText.getText().toString();

        EditText passwordEditText = (EditText) findViewById(R.id.edPassword);
        String password = passwordEditText.getText().toString();

        if(isValidEmail(email)){
            OkHttpClient client = new OkHttpClient();
            String url = "https://smtpservers.ru/projects/Kochnev/authUsers?email="+email+"&password="+password;
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String json = response.body().string();
                    if (json.equals("004")) {
                        Handler handler = new Handler(Looper.getMainLooper());
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "Неверный email или пароль!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        Gson gson = new Gson();
                        User[] users = gson.fromJson(json, User[].class);


                        SQLiteDatabase db = getBaseContext().openOrCreateDatabase("users.db",MODE_PRIVATE,null);
                        db.execSQL("CREATE TABLE IF NOT EXISTS users (id INTEGER, email TEXT, Name TEXT)");
                        String exception = String.format("INSERT INTO users (id,email,Name) VALUES ('%s', '%s', %s)", users[0].id, users[0].email, users[0].name);
                        db.execSQL(exception);
                        db.close();
                        startProfile();

                    }
                }
                @Override
                public void onFailure(Call call, IOException e) {
                    String error = e.toString();
                }
            });
        }

    }
    public static boolean isValidEmail(String email) {
        // Проверяем на null
        if (email == null) {
            return false;
        }

        // Задаем паттерн регулярного выражения для email
        Pattern pattern = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

        // Сравниваем строку с паттерном
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
    public class User {
        private int id;
        private String email;
        private String name;

    }
    public void startProfile()
    {
        startActivity(new Intent(this, MainPage.class ));
    }


    }


